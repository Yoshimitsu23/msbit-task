'use strict';

module.exports = require('request-promise-core/errors');
